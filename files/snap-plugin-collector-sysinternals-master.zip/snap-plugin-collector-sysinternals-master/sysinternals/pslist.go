package sysinternals

import (
	"fmt"
	"log"
	"os/exec"
	"path"
	"regexp"
	"runtime"
	"strconv"
	"strings"

	"github.com/intelsdi-x/snap-plugin-lib-go/v1/plugin"
)

type SysinternalsCollector struct {
}

var splitter = regexp.MustCompile("\\s+") //so this is not recomplied each time

/*
* CollectMetrics collects metrics for testing.
* CollectMetrics() is be called by Snap when a task (which is collecting one+ of the metrics returned from the GetMetricTypes()) is started.
* Input: A slice of all the metric types being collected.
* Output: A slice (list) of the collected metrics as plugin.Metric with their values and an error if failure.
 */
func (SysinternalsCollector) CollectMetrics(mts []plugin.Metric) ([]plugin.Metric, error) {
	metrics := []plugin.Metric{} // Create a slice of MetricType objects. This is where the metrics requested by the task will be stored

	_, currentFilePath, _, _ := runtime.Caller(0) //get the current directory
	dirpath := path.Dir(currentFilePath)
	dirpath = strings.Replace(dirpath, "/", "\\", -1) //change the / to \ cause windows

	//http://stackoverflow.com/questions/6182369/exec-a-shell-command-in-go
	cmd := exec.Command("pslist.exe", "/accepteula", "-nobanner") // automatically accept eula if applicable, remove banner
	stdout, err := cmd.Output()

	//if the pslist exe does not exist
	if err != nil {
		fmt.Println(err.Error()) //print out the error message
		fmt.Println("Please Download the Pslist.exe file from PsTools and place into the plugin directory")
	}

	pslistOutput := string(stdout) // turn the output into a string

	var stringSlice []string
	stringSlice = strings.Split(pslistOutput, "\n")           //This splits the output into lines in a Slice
	stringSlice = append(stringSlice[:0], stringSlice[3:]...) //This removes the additional information (blank line and headings to column)
	stringSlice = stringSlice[:len(stringSlice)-1]            //This removes the last line (which is blank)

	var threadCount int
	var handleCount int
	var processCount int

	//we can find how many items we should have: rows x items in row (doesn't change)
	for _, row := range stringSlice {
		columns := splitter.Split(row, -1)

		/*
			[!] this will reverse the order of the Slice
			this is required as the first entry is the name of the process
			this name could have spaces and/or numbers
			if the length of the name is too long there will not be two whitespaces at its end

			If reversed, there will be a whitespace delimiter for the columns that are needed, the name is safely ignored
		*/
		for i, j := 0, len(columns)-1; i < j; i, j = i+1, j-1 {
			columns[i], columns[j] = columns[j], columns[i]
		}
		processCount++
		//#3 will be the handle
		hndCount, err := strconv.Atoi(columns[4]) //get the string that is the handle number and convert it
		if err != nil {
			log.Fatal(err)
			fmt.Println("Process has been counted, thread/handle unable to be counted")
			break
		}
		handleCount += hndCount //add the handle count to the master variable

		//#4 will be the thread
		thdCount, err := strconv.Atoi(columns[5]) //get the string that is the thread number and convert it
		if err != nil {
			log.Fatal(err)
			fmt.Println("Process has been counted, thread/handle unable to be counted")
			break
		}
		threadCount += thdCount //add the thread count to the master variable
	}

	metricNames := make([]string, 0)
	for _, mt := range mts {
		metricNames = append(metricNames, mt.Namespace[len(mt.Namespace)-1].Value)
	}
	// Iterate through each of the metrics specified by task to collect
	for idx, mt := range mts {
		if _, err := mt.Config.GetString("test"); err == nil {
			continue
		}
		if mt.Namespace[len(mt.Namespace)-1].Value == "threadCount" {
			if val, err := mt.Config.GetInt("testint"); err == nil {
				mts[idx].Data = val
			} else {
				mts[idx].Data = threadCount
			}
			metrics = append(metrics, mts[idx])
		} else if mt.Namespace[len(mt.Namespace)-1].Value == "handleCount" {
			if val, err := mt.Config.GetInt("testint"); err == nil {
				mts[idx].Data = val
			} else {
				mts[idx].Data = handleCount
			}
			metrics = append(metrics, mts[idx])
		} else if mt.Namespace[len(mt.Namespace)-1].Value == "processCount" {
			if val, err := mt.Config.GetInt("testint"); err == nil {
				mts[idx].Data = val
			} else {
				mts[idx].Data = processCount
			}
			metrics = append(metrics, mts[idx])
		}
	}
	return metrics, nil
}

/*
 * GetMetricTypes returns a list of available metric types
 * GetMetricTypes() is called when this plugin is loaded in order to populate the "metric catalog" (where Snap
 * stores all of the available metrics for each plugin)
 * Input: Config info. This information comes from global Snap config settings
 * Output: A slice (list) of all plugin metrics, which are available to be collected by tasks
 */
func (SysinternalsCollector) GetMetricTypes(cfg plugin.Config) ([]plugin.Metric, error) {
	// slice to store list of all available perfmon metrics
	mts := []plugin.Metric{}

	mts = append(mts, plugin.Metric{
		Namespace: plugin.NewNamespace("intel", "sysinternals", "threadCount"),
		Version:   1,
	})

	mts = append(mts, plugin.Metric{
		Namespace: plugin.NewNamespace("intel", "sysinternals", "handleCount"),
		Version:   1,
	})
	mts = append(mts, plugin.Metric{
		Namespace: plugin.NewNamespace("intel", "sysinternals", "processCount"),
		Version:   1,
	})
	return mts, nil
}

/*
 * GetConfigPolicy() returns the config policy for this plugin
 *   A config policy allows users to provide configuration info to the plugin and is provided in the task. Here we define what kind of config info this plugin can take and/or needs.
 */
func (SysinternalsCollector) GetConfigPolicy() (plugin.ConfigPolicy, error) {
	policy := plugin.NewConfigPolicy()

	// This rule is simply for unit testing, so I can pass in my own values for each metric rather than getting them from counters.go
	policy.AddNewFloatRule([]string{"random", "float"},
		"testfloat",
		false,
		plugin.SetMaxFloat(1000.0),
		plugin.SetMinFloat(0.0))

	// For now, assuming that perfmon has no configs. May need to add some if permissions becomes an issue.
	return *policy, nil
}
